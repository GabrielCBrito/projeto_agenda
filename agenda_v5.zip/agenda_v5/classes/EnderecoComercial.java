package classes;

public class EnderecoComercial extends Endereco {
  
  private String telefoneComercial;

  public String getTelefoneComercial() {
    return telefoneComercial;
  }

  public void setTelefoneComercial(String telefoneComercial) {
    this.telefoneComercial = telefoneComercial;
  }

}
