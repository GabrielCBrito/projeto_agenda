package classes;

public class Endereco {
  
  private String nmLogradouro;

  private String cep;

  public String getCep() {
    return cep;
  }

  public String getNmLogradouro() {
    return nmLogradouro;
  }

  public void setCep(String cep) {
    this.cep = cep;
  }

  public void setNmLogradouro(String nmLogradouro) {
    this.nmLogradouro = nmLogradouro;
  }

}
