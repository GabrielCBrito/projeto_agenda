package classes;

public class EnderecoResidencial extends Endereco {
  
  private String telefoneResidencial;

  public String getTelefoneResidencial() {
    return telefoneResidencial;
  }

  public void setTelefoneResidencial(String telefoneResidencial) {
    this.telefoneResidencial = telefoneResidencial;
  }

}
