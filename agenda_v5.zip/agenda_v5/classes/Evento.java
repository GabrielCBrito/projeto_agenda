package classes;

public class Evento {

  private String nmEvento;

  private String dtEvento;

  private String tipoEvento;

  public void setNmEvento(String nome){
    nmEvento = nome;
  }

  public String getNmEvento(){
    return nmEvento;
  }

  public String getDtEvento() {
    return dtEvento;
  }

  public void setDtEvento(String dtEvento) {
    this.dtEvento = dtEvento;
  }

  public String getTipoEvento() {
    return tipoEvento;
  }

  public void setTipoEvento(String tipoEvento) {
    this.tipoEvento = tipoEvento;
  }
  
}
