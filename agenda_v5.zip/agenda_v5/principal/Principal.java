package principal;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import classes.Agenda;
import classes.Contato;
import classes.Endereco;
import classes.EnderecoComercial;
import classes.EnderecoResidencial;
import classes.Evento;
import classes.TipoContato;

public class Principal {
  
  public static void main(String[] args) {

    Scanner s = new Scanner(System.in);
    
    Agenda a = new Agenda();
    Contato c;
    Evento e;

    List<Contato> listaContato = new ArrayList<Contato>();
    List<Evento> listaEvento = new ArrayList<Evento>();

    System.out.println("********************");
    System.out.println("        MENU        ");
    System.out.println("********************");
    System.out.println("1 - Cadastrar contato");
    System.out.println("2 - Cadastrar evento");
    System.out.println("********************");
    System.out.print("Digite uma opção: ");
    int opcao = s.nextInt();

    switch(opcao){
      case 1:
        c = cadastrarContato(s);
        listaContato.add(c);
        a.setContatos(listaContato);
        break;
      case 2:
        e = cadastrarEvento(s);
        listaEvento.add(e);
        a.setEventos(listaEvento);
        break;
      default:
      System.out.println("Opção de menu inválida!");
    }

    mostrarContatos(listaContato);
    mostrarEventos(listaEvento);

    s.close();

  }

  public static Contato cadastrarContato(Scanner s){

    s.nextLine();

    System.out.print("Digite o nome do contato: ");
    String nome = s.nextLine();

    System.out.print("Digite o telefone do contato: ");
    String telefone = s.nextLine();

    System.out.print("Digite a data de nascimento do contato: ");
    String dtNascimento = s.nextLine();

    Contato c = new Contato();

    c.setNome(nome);

    System.out.println("Digite o tipo de endereço(R ou C): ");
    String end = s.nextLine();

    Endereco endereco = new Endereco();
    if(end.toUpperCase().equals("R")){
      EnderecoResidencial endRes = new EnderecoResidencial();
      endereco = endRes;
      endRes.setTelefoneResidencial(telefone);
    } else if(end.toUpperCase().equals("C")){
      EnderecoComercial endCom = new EnderecoComercial();
      endereco = endCom;
      endCom.setTelefoneComercial(telefone);
    }

    c.setEndereco(endereco);

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    LocalDate ld = LocalDate.parse(dtNascimento, dtf);
    c.setDtNascimento(ld);

    c.setTipoContato(TipoContato.FAMILIA);

    return c;
  }

  public static Evento cadastrarEvento(Scanner s){
    s.nextLine();
    
    System.out.print("Digite o nome do evento: ");
    String nmEvento = s.nextLine();

    Evento e = new Evento();
    e.setNmEvento(nmEvento);

    return e;
  }

  public static void mostrarContatos(List<Contato> listaContato){
    if(listaContato.size() != 0){
      Contato c = listaContato.get(listaContato.size() - 1);

      System.out.println("Nome: "+c.getNome());
    }
  }

  public static void mostrarEventos(List<Evento> listaEvento){
    if(listaEvento.size() != 0){
      Evento e = listaEvento.get(listaEvento.size() - 1);
      System.out.println(e.getNmEvento());
    }
  }

}
